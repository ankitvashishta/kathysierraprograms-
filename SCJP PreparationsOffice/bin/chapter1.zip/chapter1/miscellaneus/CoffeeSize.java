package chapter1.miscellaneus;

public enum CoffeeSize {

	BIG, HUGE, OVERWHELMING
}
