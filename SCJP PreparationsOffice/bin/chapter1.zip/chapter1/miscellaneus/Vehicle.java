package chapter1.miscellaneus;

public class Vehicle {
	
	protected int x = 0;

}
