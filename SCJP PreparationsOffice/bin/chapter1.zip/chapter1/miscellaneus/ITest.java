package chapter1.miscellaneus;

public interface ITest {
	
	void checkTest();

}
