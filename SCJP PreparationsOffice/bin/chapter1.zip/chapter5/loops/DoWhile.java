package chapter5.loops;

public class DoWhile {
	
	public static void main(String args[]){
		int x=0;
		do{
			System.out.println(x);
			x++;
		}while(x<5);
		System.out.println("***************************************");
		x=0;
		while(x<5){
			System.out.println(x);
			x++;
		}
	}

}
