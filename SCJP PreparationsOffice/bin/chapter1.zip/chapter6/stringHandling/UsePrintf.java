package chapter6.stringHandling;

public class UsePrintf {
	public static void main(String args[]){
		System.out.printf("%2$d + %1$d", 12, 32);
	}

}
